import replNeverSleep
replNeverSleep.awake('https://NeverSleep.c4syner.repl.co', True) #Param 1: Link to this repl's website, Param 2: Debug Set to true (print status code for the request, good=200)
#Thats it! 
#Feel free to code below without your program ever going to sleep!

while(True):
    name = input("What's your name? ")
    print("Hello " + name)